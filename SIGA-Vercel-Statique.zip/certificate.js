(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.SIGACertificate=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';

  const specialBytes={
    '€':0x80,'‚':0x82,'ƒ':0x83,'„':0x84,'…':0x85,'†':0x86,'‡':0x87,'ˆ':0x88,'‰':0x89,'Š':0x8a,'‹':0x8b,'Œ':0x8c,'Ž':0x8e,
    '‘':0x91,'’':0x92,'“':0x93,'”':0x94,'•':0x95,'–':0x96,'—':0x97,'˜':0x98,'™':0x99,'š':0x9a,'›':0x9b,'œ':0x9c,'ž':0x9e,'Ÿ':0x9f
  };
  const safe=value=>String(value??'').replace(/\s+/g,' ').trim();
  function pdfText(value){
    let result='';
    for(const char of safe(value)){
      const code=specialBytes[char]??char.codePointAt(0);
      const byte=code<=255?code:63;
      if(byte===40||byte===41||byte===92)result+='\\'+String.fromCharCode(byte);
      else if(byte<32||byte>126)result+='\\'+byte.toString(8).padStart(3,'0');
      else result+=String.fromCharCode(byte);
    }
    return result;
  }
  function width(value,size){return safe(value).length*size*0.51;}
  function centered(value,size){return Math.max(45,(595.28-width(value,size))/2);}
  function text(value,x,y,size,font='F1',color='0.16 0.23 0.29'){
    return `BT /${font} ${size} Tf ${color} rg 1 0 0 1 ${x.toFixed(2)} ${y.toFixed(2)} Tm (${pdfText(value)}) Tj ET`;
  }
  function centeredText(value,y,size,font='F1',color='0.16 0.23 0.29'){
    return text(value,centered(value,size),y,size,font,color);
  }
  function wrap(value,max=64){
    const words=safe(value).split(' '),lines=[];let line='';
    for(const word of words){
      const next=line?`${line} ${word}`:word;
      if(next.length>max&&line){lines.push(line);line=word;}else line=next;
    }
    if(line)lines.push(line);
    return lines.slice(0,3);
  }
  function dateLabel(value){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(String(value||'')))return safe(value)||'—';
    return `${value.slice(8,10)}/${value.slice(5,7)}/${value.slice(0,4)}`;
  }
  function stableId(data){
    const source=`${safe(data.sessionId)}|${safe(data.employeeId)}|${safe(data.score)}|${safe(data.maxScore)}`;
    let hash=2166136261;
    for(let i=0;i<source.length;i++){hash^=source.charCodeAt(i);hash=Math.imul(hash,16777619);}
    return `SIGA-FORM-${String(data.issueDate||'').slice(0,4)||'0000'}-${(hash>>>0).toString(16).toUpperCase().padStart(8,'0')}`;
  }
  function createCertificatePdf(data){
    const start=dateLabel(data.startDate),end=dateLabel(data.endDate),issue=dateLabel(data.issueDate);
    const titleLines=wrap(data.trainingTitle,58),commands=[];
    commands.push('q 0.965 0.975 0.980 rg 0 0 595.28 841.89 re f Q');
    commands.push('q 0.09 0.27 0.31 RG 2 w 32 32 531.28 777.89 re S Q');
    commands.push('q 0.08 0.43 0.38 rg 32 774 531.28 36 re f Q');
    commands.push(centeredText('SIGASÉCURITÉ',781,14,'F2','1 1 1'));
    commands.push(centeredText('ATTESTATION DE FORMATION',704,19,'F2','0.08 0.27 0.31'));
    commands.push('q 0.71 0.57 0.26 RG 1.4 w 206 685 m 389 685 l S Q');
    const employeeLines=wrap(safe(data.employeeName)||'Agent',38).slice(0,2);
    commands.push(centeredText('Nous certifions que',651,12,'F1','0.35 0.42 0.47'));
    let employeeY=employeeLines.length>1?621:613;
    for(const line of employeeLines){commands.push(centeredText(line,employeeY,22,'F2','0.08 0.27 0.31'));employeeY-=25;}
    const statementY=employeeLines.length>1?557:570;
    commands.push(centeredText('a suivi avec succès la formation',statementY,12,'F1','0.35 0.42 0.47'));
    let titleY=statementY-35;
    for(const line of titleLines){commands.push(centeredText(line,titleY,15,'F2','0.08 0.43 0.38'));titleY-=24;}
    commands.push('q 0.82 0.87 0.87 RG 0.8 w 88 455 m 507 455 l S Q');
    const period=`${start} au ${end}`;
    const rows=[
      ['Période suivie',period],
      ['Résultat','Réussi'],
      ['Note',`${safe(data.score)} / ${safe(data.maxScore)}`],
      ['Lieu',safe(data.location)||'Non renseigné'],
      ['Formateur',safe(data.trainer)||'Non renseigné']
    ];
    let y=420;
    for(const [label,value] of rows){
      commands.push(text(label,105,y,10,'F1','0.39 0.46 0.50'));
      commands.push(text(value,235,y,11,'F2','0.16 0.23 0.29'));
      y-=37;
    }
    commands.push(centeredText(`Délivrée le ${issue}`,237,10,'F1','0.35 0.42 0.47'));
    commands.push('q 0.09 0.27 0.31 RG 0.8 w 351 191 m 493 191 l S Q');
    commands.push(text('Responsable de formation',370,174,9,'F1','0.35 0.42 0.47'));
    commands.push(text('Signature et cachet',384,158,8,'F1','0.55 0.60 0.63'));
    commands.push(text(stableId(data),49,67,8,'F1','0.39 0.46 0.50'));
    commands.push(text('Document généré depuis le registre de formation SIGASÉCURITÉ.',49,51,8,'F1','0.39 0.46 0.50'));

    const stream=commands.join('\n');
    const objects=[
      '<< /Type /Catalog /Pages 2 0 R >>',
      '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
      '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> /Contents 4 0 R >>',
      `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
      '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
      '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'
    ];
    let pdf='%PDF-1.4\n',offsets=[0];
    for(let i=0;i<objects.length;i++){
      offsets.push(pdf.length);
      pdf+=`${i+1} 0 obj\n${objects[i]}\nendobj\n`;
    }
    const xref=pdf.length;
    pdf+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
    for(let i=1;i<offsets.length;i++)pdf+=`${String(offsets[i]).padStart(10,'0')} 00000 n \n`;
    pdf+=`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
    if(typeof Buffer!=='undefined')return Buffer.from(pdf,'ascii');
    return new TextEncoder().encode(pdf);
  }
  return {createCertificatePdf};
});
